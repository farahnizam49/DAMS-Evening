<?php
if(isset($_POST['dept_id']) && isset($_POST['batch_id']) && isset($_POST['term_id']) && isset($_POST['percent_id'])){
    $dept_id = $_POST['dept_id'];
    $batch_id = $_POST['batch_id'];
    $term_id = $_POST['term_id'];
    $percent_id = $_POST['percent_id'];
    // echo $dept_id;
    header("location:./showStudentsAttendancefunc.php?dept_id=".$dept_id."&batch_id=".$batch_id."&term_id=".$term_id."&percent_id=".$percent_id);
}

?>
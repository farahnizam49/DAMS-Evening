<div class="sidebar " id="sidebar">
    <div class="sidebar-inner " id="sidebar-inner">
        <p>D.A.M.S</p>
        <hr>
        <div class="row-sidebar">
            <a href="./index.php"> <i class="far fa-user-circle icon-sidebar"></i>
                <div class="row-sidebar-text name-bar ">
                    HOD
                </div>
            </a>
        </div>
        <hr>
        <div class="row-sidebar">
            <a href="./viewattendance.php">
               <i class="far fa-eye icon-sidebar"></i>
                <div class="row-sidebar-text ">
                    View Attendance
                </div>
            </a>
        </div>
        <div class="row-sidebar">
            <a href="./viewstudents.php">
               <i class="far fa-eye icon-sidebar"></i>
                <div class="row-sidebar-text ">
                    View Students
                </div>
            </a>
        </div>
        <div class="row-sidebar">
            <a href="./showperiod.php">
            <i class="far fa-eye icon-sidebar"></i>
                <div class="row-sidebar-text ">
                    View Period Table
                </div>
            </a>
        </div>
      
        <div class="row-sidebar">
            <a href="../logout.php">
            <i class="fas fa-sign-out-alt icon-sidebar"></i>
            <div class="row-sidebar-text ">
                Logout
            </div>
            </a>
           
        </div>


    </div>





</div>
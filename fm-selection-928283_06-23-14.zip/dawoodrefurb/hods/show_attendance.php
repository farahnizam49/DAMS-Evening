<?php


if(isset($_POST['dept_id']) && isset($_POST['batch_id']) ){
    header("location:./show_class.php?dept_id=2&&batch_id=1")
    // send the ids to show class attendance page
}
else if(isset($_POST['dept_id'])){
// send the id to show dept attendance page
}
else if(isset($_POST['batch_id'])){
// send the id to show batch attendance page

}
else{
    // send the user back to ./index.php
    // meaning no id 
}
?>


                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
$_GET['dept_id']
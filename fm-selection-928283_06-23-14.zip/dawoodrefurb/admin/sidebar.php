<div class="sidebar " id="sidebar">
    <div class="sidebar-inner" id="sidebar-inner">
        <p style="text-align:center">D.A.M.S</p>
        <hr>
        <div class="row-sidebar profile">
            <a href="./index.php">
            <i class="far fa-user-circle icon-sidebar"></i>
            <div class="row-sidebar-text name-bar ">
                Admin
            </div>
            </a>
        </div>
        <div class="row-sidebar">
            <a href="./attendedClasses.php">

                <i class="fas fa-file-upload icon-sidebar"></i>
                <div class="row-sidebar-text ">
                    View Teacher's Attended Classes
                </div>
            </a>
        </div>
        <div class="row-sidebar">
            <a href="./showStudentsAttendance.php">

                <i class="fas fa-file-upload icon-sidebar"></i>
                <div class="row-sidebar-text ">
                    View Student's Attendance % Wise
                </div>
            </a>
        </div>
        <div class="row-sidebar">
            <a href="../logout.php">
                <i class="fas fa-sign-out-alt icon-sidebar"></i>
                <div class="row-sidebar-text ">
                    Logout
                </div>
            </a>
        </div>
    </div>

</div>
<?php

function arrtoLoop(){

}

?>